!******************************************************************************
!                  ��������������ŵ��Ӧ��
!*******************************************************************************
	  
	  implicit doubleprecision (a-h,o-z) 
          real*8,allocatable,dimension(:,:,:):: d,u,v,w,T       ! .average
	  real*8,allocatable,dimension(:,:,:)::d2,u2,v2,w2,T2   ! .average2
          real*8,allocatable,dimension(:,:,:)::uu,vv,ww !��ŵ��Ӧ��
          real*8,allocatable,dimension(:)::d1,u1,v1,w1,T1   !����������ƽ��ֵ
	  real*8,allocatable,dimension(:)::uu1,vv1,ww1 !��ŵ��Ӧ���Ŀռ�ƽ��ֵ
	  real*8,allocatable,dimension(:,:)::uu2,vv2,ww2 !Z����ƽ������ŵ��Ӧ��
          real*8,allocatable:: xx(:),yy(:),zz(:)    ! X��Z����ռ�ƽ����ľ�ֵ
	  real*8,allocatable:: yplus(:),uplus(:)
          real*8 tt,Tw
	  real*8 miu_w, tau_w, u_tau, Re_tau
	      integer istep
	      integer IT
	      character(len=120) filename
	      character(len=120) savename
	      character(len=8) Cnum
	      logical file_exist
!-----------------------------------------
          gamma=1.4d0
          open(33,file="../opencfd.in")
          do k=1,4
          read(33,*)
          enddo
          read(33,*) nx,ny,nz ! ��5�п�ʼ��
          do k=1,7
          read(33,*)
          enddo
	  read(33,*) SLx,SLy,SLz  ! ��13�п�ʼ��
	  read(33,*)
	 
          read(33,*) Re,Ama,tmp,tmp,tmp,tmp,T_inf  ! ��15�п�ʼ��
          do k=1,13
		  read(33,*)
		  enddo
		  read(33,*) tmp,tmp,tmp,tpm,Tw    ! ��29�п�ʼ��
		  close(33)  
          print*, "nx,ny=",nx,ny,nz
		  print*, "Re,Ama,T_inf=",Re,Ama,T_inf
          print*, "Tw=",Tw

          Tsb=110.4/T_inf
	  miu_w=1.0/Re*(1.0+Tsb)*sqrt(Tw**3)/(Tsb+Tw)
          !Amu_w=1.0/Re*(1.0+Tsb)*sqrt(Tw**3)/(Tsb+Tw)  ! 2024.5.16�滻
          p00=1.d0/(gamma*Ama*Ama)

	  print*, "Tsb, miu_w, p00=",Tsb, miu_w, p00


       allocate(xx(nx),yy(ny),zz(nz))
       allocate(d(nx,ny,nz),u(nx,ny,nz),v(nx,ny,nz),w(nx,ny,nz),T(nx,ny,nz))
       allocate(d2(nx,ny,nz),u2(nx,ny,nz),v2(nx,ny,nz),w2(nx,ny,nz),T2(nx,ny,nz))
       allocate(uu(nx,ny,nz),vv(nx,ny,nz),ww(nx,ny,nz))
       allocate(d1(ny),u1(ny),v1(ny),w1(ny),T1(ny))
       allocate(uu1(ny),vv1(ny),ww1(ny))
       allocate(uu2(nx,ny),vv2(nx,ny),ww2(nx,ny))  ! Z����ƽ������ŵ��Ӧ��
       allocate(yplus(ny),uplus(ny))

!------------------------------------------------------
	   PI=3.14159265358979d0
	   hx = (SLx) / (nx-1)
	   hy = (SLy) / (ny-1)
           hz = (SLz) / (nz-1)
!---------read grid message --------------------------
	  open(66,file="../ocfd-grid.dat",form="unformatted")
	  !read(66) xx   ! X��Z����Ϊ�������񣬲���Ҫ����
	  read(66) yy    ! ����Y����ķǾ�������
	  close(66)

          
      Do i=1,nx
          xx(i)=(i-1.d0)/(nx-1.d0)*SLx
      enddo  
    
      Do i=1,nz
          zz(i)=(i-1.d0)/(nz-1.d0)*SLz
      enddo 

    
      Istep=0
	  tt=0.d0

!---------read series.txt--------------------------
      
      
      open(19,file="series.txt",form="formatted")
      read(19,*)    
      read(19,*) temp,IT,temp
      close(19)  

        
         
!---------read .average data------------------------
          
         write(Cnum,"(I8.8)") mod(IT,100000000)
         filename='../OCFD'//Cnum//'.dat.average'
         inquire(file=filename,exist=file_exist)          
         if(file_exist) then
         print*,"ok,",filename
         open(33,file=filename,form="unformatted")
         read(33) Istep,tt
         print*,Istep,tt
		 do k=1,nz
	     read(33) d(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) u(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) v(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) w(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) T(:,:,k)
	     enddo
         close(33)
      
        
         print*, "read data OK ..."
	 endif

!---------read .average2 data------------------------
          
         write(Cnum,"(I8.8)") mod(IT,100000000)
         filename='../OCFD'//Cnum//'.dat.average2'
         inquire(file=filename,exist=file_exist)          
         if(file_exist) then
         print*,"ok,",filename
         open(33,file=filename,form="unformatted")
         read(33) Istep,tt
         print*,Istep,tt
		 do k=1,nz
	     read(33) d2(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) u2(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) v2(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) w2(:,:,k)
	     enddo
		 do k=1,nz
	     read(33) T2(:,:,k)
	     enddo
         close(33)
      
        
         print*, "read data OK ..."
	 endif

!---------calculate the normal Reynolds stress------------------------

             do k=1,nz
	     DO j=1,ny
	     DO i=1,nx
                uu(i,j,k) = sqrt(  abs( u2(i,j,k)-u(i,j,k)*u(i,j,k) )  )
                vv(i,j,k) = sqrt(  abs( v2(i,j,k)-v(i,j,k)*v(i,j,k) )  )
		ww(i,j,k) = sqrt(  abs( w2(i,j,k)-w(i,j,k)*w(i,j,k) )  )
	     enddo
	     enddo
	     enddo


!---------make spacial average------------------------

        d1=0.d0;u1=0.d0;v1=0.d0;w1=0.d0;T1=0.d0
	uu1=0.d0;vv1=0.d0;ww1=0.d0
        uu2=0.d0;vv2=0.d0;ww2=0.d0

		
	do j=1,ny  
	  do k=1,nz
          do i=1,nx
	    d1(j)=d1(j)+d(i,j,k)
	    u1(j)=u1(j)+u(i,j,k)
	    v1(j)=v1(j)+v(i,j,k)
	    w1(j)=w1(j)+w(i,j,k)
	    T1(j)=T1(j)+T(i,j,k)
	  enddo 
	  enddo
	    d1(j)=d1(j)/(nx*nz)
	    u1(j)=u1(j)/(nx*nz)
	    v1(j)=v1(j)/(nx*nz)
	    w1(j)=w1(j)/(nx*nz)
	    T1(j)=T1(j)/(nx*nz)
	enddo

	do j=1,ny  
	  do k=1,nz
          do i=1,nx
	
	    uu1(j)=uu1(j)+uu(i,j,k)
	    vv1(j)=vv1(j)+vv(i,j,k)
	    ww1(j)=ww1(j)+ww(i,j,k)
	 
	  enddo 
	  enddo
	
	    uu1(j)=uu1(j)/(nx*nz)
	    vv1(j)=vv1(j)/(nx*nz)
	    ww1(j)=ww1(j)/(nx*nz)
	
	enddo

	do j=1,ny  
	do i=1,nx

	  do k=1,nz          	
	    uu2(i,j)=uu2(i,j)+uu(i,j,k)
	    vv2(i,j)=vv2(i,j)+vv(i,j,k)
	    ww2(i,j)=ww2(i,j)+ww(i,j,k)	  
	  enddo
	
	    uu2(i,j)=uu2(i,j)/(nz)
	    vv2(i,j)=vv2(i,j)/(nz)
	    ww2(i,j)=ww2(i,j)/(nz)
	
	enddo
	enddo



        tau_w = miu_w * (u1(2)-u1(1))/(yy(2)-yy(1)) 
	u_tau = sqrt(tau_w/d1(1))              ! �ܶ�ȡ���洦���ܶ�
	Re_tau = u_tau*SLy*d1(1)/(2.d0*miu_w)  ! ������ȡ���洦��ֵ
        print*, "rho_w=",d1(1)
	print*, "tau_w, u_tau, Re_tau=",tau_w, u_tau, Re_tau

	do j=1,ny  
	  yplus(j) = Re_tau *2 / SLy * yy(j)
	  uplus(j) = u1(j) / u_tau
	enddo

!---------output u+ , y+ and normal Reynolds stress -----------------------------------------------

        ! ����ɶ���X��Z����ƽ���������һ����������ŵ��Ӧ��      
        savename='normal_ReyStress'//Cnum//'.dat'
        open(44,file=savename,form="formatted")
	write(44,*) 'Title = "Comput." '
        write(44,'(A113)',advance='no') "variables=y<sup>+</sup>,<u<sup>+</sup>'u<sup>+</sup>'>, &
	    <v<sup>+</sup>'v<sup>+</sup>'>,<w<sup>+</sup>'w<sup>+</sup>'>"
	write(44,*) 'ZONE T="Comput." '
     	!write(44,*) "zone i= ",nx, " j= ",ny
	    
        do j=2,ny-1
       
	   write(44,"(4f16.8)") yplus(j), uu1(j)/u_tau, vv1(j)/u_tau,ww1(j)/u_tau
	   
        enddo
       
	    close(44)
	    

        ! ���Z=0�������һ����������ŵ��Ӧ��
	savename='ReyNorm2dXY'//Cnum//'.plt'
        open(46,file=savename,form="formatted")
        write(46,*) "variables=x,y,<u'u'>, <v'v'>, <w'w'>"
     	write(46,*) "zone i= ",nx, " j= ",ny
	    
        do j=1,ny
        do i=1,nx
	       write(46,"(5f16.8)") xx(i),yy(j),uu2(i,j),vv2(i,j),ww2(i,j)
	    enddo
        enddo
       
	    close(46)
	    
	    
	    
	    
	    
	    
	    
	    
	    end