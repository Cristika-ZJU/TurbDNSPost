!******************************************************************************
!                  �����ŵ��Ӧ������Ӧ��
!*******************************************************************************
	  
    implicit doubleprecision (a-h,o-z) 
    real*8,allocatable,dimension(:,:,:):: da,ua,va,wa,Ta       ! .average
    real*8,allocatable,dimension(:,:,:):: dd,uu,vv,ww,TT        ! .average2
    real*8,allocatable,dimension(:,:,:):: uv,vw,uw              ! .average3
    real*8,allocatable,dimension(:,:,:):: suu,svv,sww          ! ��ŵ��Ӧ��
    real*8,allocatable,dimension(:,:,:):: suv,svw,suw          ! ��ŵ��Ӧ��
    
    real*8,allocatable,dimension(:)::d_ar,u_ar,v_ar,w_ar,T_ar   !����������ƽ��ֵ
    real*8,allocatable,dimension(:)::suua,svva,swwa             !��ŵ��Ӧ���Ŀռ�ƽ��ֵ
    real*8,allocatable,dimension(:)::suva,svwa,suwa             !��ŵ��Ӧ���Ŀռ�ƽ��ֵ
    real*8,allocatable,dimension(:,:)::uu2,vv2,ww2 !Z����ƽ������ŵ��Ӧ��
    real*8,allocatable:: xx(:),yy(:),zz(:)    ! X��Z����ռ�ƽ����ľ�ֵ
    real*8,allocatable:: yplus(:),uplus(:)
    real*8 ti,Tw
    real*8 miu_w, tau_w, u_tau, Re_tau
    integer istep
    integer IT
    character(len=120) filename
    character(len=120) savename
    character(len=8) Cnum
    logical file_exist
!-----------------------------------------
    gamma=1.4d0
    open(33,file="../opencfd.in")
    do k=1,4
        read(33,*)
    enddo
    read(33,*) nx,ny,nz ! ��5�п�ʼ��
    do k=1,7 
        read(33,*)
    enddo
    read(33,*) SLx,SLy,SLz  ! ��13�п�ʼ��
    read(33,*)
	 
    read(33,*) Re,Ama,tmp,tmp,tmp,tmp,T_inf  ! ��15�п�ʼ��
    do k=1,13  
        read(33,*)
    enddo
    read(33,*) tmp,tmp,tmp,tpm,Tw    ! ��29�п�ʼ��
    close(33)  
    print*, "nx,ny,nz=",nx,ny,nz
    print*, "Re,Ama,T_inf=",Re,Ama,T_inf
    print*, "Tw=",Tw

    Tsb=110.4/T_inf
    miu_w=1.0/Re*(1.0+Tsb)*sqrt(Tw**3)/(Tsb+Tw)
    !Amu_w=1.0/Re*(1.0+Tsb)*sqrt(Tw**3)/(Tsb+Tw)  ! 2024.5.16�滻
    p00=1.d0/(gamma*Ama*Ama)

    print*, "Tsb, miu_w, p00=",Tsb, miu_w, p00


    allocate(xx(nx),yy(ny),zz(nz))
    allocate(da(nx,ny,nz),ua(nx,ny,nz),va(nx,ny,nz),wa(nx,ny,nz),Ta(nx,ny,nz))
    allocate(dd(nx,ny,nz),uu(nx,ny,nz),vv(nx,ny,nz),ww(nx,ny,nz),TT(nx,ny,nz))
    allocate(uv(nx,ny,nz),vw(nx,ny,nz),uw(nx,ny,nz))
    
    allocate( suu(nx,ny,nz),svv(nx,ny,nz),sww(nx,ny,nz) )         ! ��ŵ��Ӧ��
    allocate( suv(nx,ny,nz),svw(nx,ny,nz),suw(nx,ny,nz) )         ! ��ŵ��Ӧ��
    
    allocate(d_ar(ny),u_ar(ny),v_ar(ny),w_ar(ny),T_ar(ny))
    allocate(suua(ny),svva(ny),swwa(ny))
    allocate(suva(ny),svwa(ny),suwa(ny))
    
    allocate(uu2(nx,ny),vv2(nx,ny),ww2(nx,ny))  ! Z����ƽ������ŵ��Ӧ��
    allocate(yplus(ny),uplus(ny))

!------------------------------------------------------
    PI=3.14159265358979d0
    hx = (SLx) / (nx-1)
    hy = (SLy) / (ny-1)
    hz = (SLz) / (nz-1)
!---------read grid message --------------------------
    open(66,file="../ocfd-grid.dat",form="unformatted")
    !read(66) xx   ! X��Z����Ϊ�������񣬲���Ҫ����
    read(66) yy    ! ����Y����ķǾ�������
    close(66)

          
    Do i=1,nx
        xx(i)=(i-1.d0)/(nx-1.d0)*SLx
    enddo  
    
    Do i=1,nz
        zz(i)=(i-1.d0)/(nz-1.d0)*SLz
    enddo 

    
    Istep=0
    ti=0.d0

!---------read series.txt--------------------------
      
      
    open(19,file="series.txt",form="formatted")
    read(19,*)    
    read(19,*) temp,IT,temp
    close(19)  
       
         
!---------read .average data------------------------
          
    write(Cnum,"(I8.8)") mod(IT,100000000)
    filename='../OCFD'//Cnum//'.dat.average'
    inquire(file=filename,exist=file_exist)          
    if(file_exist) then
        print*,"ok,",filename   
        open(33,file=filename,form="unformatted")
        read(33) Istep,ti
        print*,Istep,ti
        do k=1,nz
            read(33) da(:,:,k)
        enddo
        do k=1,nz
            read(33) ua(:,:,k)
        enddo
        do k=1,nz
            read(33) va(:,:,k)
        enddo
        do k=1,nz
            read(33) wa(:,:,k)
        enddo
        do k=1,nz
            read(33) Ta(:,:,k)
        enddo
        close(33)
      
        
        print*, "read .average data OK ..."
    endif

!---------read .average2 data------------------------
          
    write(Cnum,"(I8.8)") mod(IT,100000000)
    filename='../OCFD'//Cnum//'.dat.average2'
    inquire(file=filename,exist=file_exist)          
    if(file_exist) then
        print*,"ok,",filename
        open(33,file=filename,form="unformatted")
        read(33) Istep,ti
        print*,Istep,ti
        do k=1,nz
            read(33) dd(:,:,k)
        enddo
        do k=1,nz
            read(33) uu(:,:,k)
        enddo
        do k=1,nz
            read(33) vv(:,:,k)
        enddo
        do k=1,nz
            read(33) ww(:,:,k)
        enddo
        do k=1,nz
            read(33) TT(:,:,k)
        enddo
        close(33)
      
        
        print*, "read .average2 data OK ..."
    endif

!---------read .average3 data------------------------
          
    write(Cnum,"(I8.8)") mod(IT,100000000)
    filename='../OCFD'//Cnum//'.dat.average3'
    inquire(file=filename,exist=file_exist)          
    if(file_exist) then
        print*,"ok,",filename
        open(33,file=filename,form="unformatted")
        read(33) Istep,ti
        print*,Istep,ti
        do k=1,nz
            read(33) dd(:,:,k)
        enddo
        do k=1,nz
            read(33) uv(:,:,k)
        enddo
        do k=1,nz
            read(33) vw(:,:,k)
        enddo
        do k=1,nz
            read(33) uw(:,:,k)
        enddo
        do k=1,nz
            read(33) TT(:,:,k)
        enddo
        close(33)
      
        
        print*, "read .average3 data OK ..."
    endif

!---------calculate the Reynolds stress------------------------

        
    do k=1,nz  
        do j=1,ny
            do i=1,nx
                suu(i,j,k) = uu(i,j,k)-ua(i,j,k)*ua(i,j,k)
                svv(i,j,k) = vv(i,j,k)-va(i,j,k)*va(i,j,k)
                sww(i,j,k) = ww(i,j,k)-wa(i,j,k)*wa(i,j,k) 
                
                suv(i,j,k) = uv(i,j,k)-ua(i,j,k)*va(i,j,k) 
                svw(i,j,k) = vw(i,j,k)-va(i,j,k)*wa(i,j,k) 
                suw(i,j,k) = uw(i,j,k)-ua(i,j,k)*wa(i,j,k) 
            enddo
        enddo
    enddo


!---------make spacial average------------------------

        
    d_ar=0.d0;u_ar=0.d0;v_ar=0.d0;w_ar=0.d0;T_ar=0.d0
	suua=0.d0;svva=0.d0;swwa=0.d0
    suva=0.d0;svwa=0.d0;suwa=0.d0
        
    uu2=0.d0;vv2=0.d0;ww2=0.d0

		
	do j=1,ny  
        do k=1,nz
            do i=1,nx
                d_ar(j)=d_ar(j)+da(i,j,k)
                u_ar(j)=u_ar(j)+ua(i,j,k)
                v_ar(j)=v_ar(j)+va(i,j,k)
                w_ar(j)=w_ar(j)+wa(i,j,k)
                T_ar(j)=T_ar(j)+Ta(i,j,k)
            enddo 
        enddo
        d_ar(j)=d_ar(j)/(nx*nz)
        u_ar(j)=u_ar(j)/(nx*nz)
	    v_ar(j)=v_ar(j)/(nx*nz)
	    w_ar(j)=w_ar(j)/(nx*nz)
	    T_ar(j)=T_ar(j)/(nx*nz)
    enddo

	
    
    do j=1,ny  
	  do k=1,nz
          do i=1,nx
              suua(j)=suua(j)+suu(i,j,k)
              svva(j)=svva(j)+svv(i,j,k)
              swwa(j)=swwa(j)+sww(i,j,k)
              suva(j)=suva(j)+suv(i,j,k)
              svwa(j)=svwa(j)+svw(i,j,k)
              suwa(j)=suwa(j)+suw(i,j,k)
          enddo 
      enddo
	    suua(j)=suua(j)/(nx*nz)
	    svva(j)=svva(j)/(nx*nz)
	    swwa(j)=swwa(j)/(nx*nz)
        suva(j)=suva(j)/(nx*nz)
	    svwa(j)=svwa(j)/(nx*nz)
	    suwa(j)=suwa(j)/(nx*nz)
	enddo

	!do j=1,ny  
 !       do i=1,nx
 !           
 !           do k=1,nz          	
 !               uu2(i,j)=uu2(i,j)+uu(i,j,k)
 !               vv2(i,j)=vv2(i,j)+vv(i,j,k)
 !               ww2(i,j)=ww2(i,j)+ww(i,j,k)	  
 !           enddo
	!
 !           uu2(i,j)=uu2(i,j)/(nz)
 !           vv2(i,j)=vv2(i,j)/(nz)
 !           ww2(i,j)=ww2(i,j)/(nz)
	!
	!enddo
	!enddo



    tau_w = miu_w * (u_ar(2)-u_ar(1))/(yy(2)-yy(1)) 
	u_tau = sqrt(tau_w/d_ar(1))              ! �ܶ�ȡ���洦���ܶ�
	Re_tau = u_tau*SLy*d_ar(1)/(2.d0*miu_w)  ! ������ȡ���洦��ֵ
    print*, "rho_w=",d_ar(1)
	print*, "tau_w, u_tau, Re_tau=",tau_w, u_tau, Re_tau

	do j=1,ny  
        yplus(j) = Re_tau *2 / SLy * (yy(j)-yy(1))
        uplus(j) = u_ar(j) / u_tau
	enddo

!---------output ua+ , y+ and Reynolds stress -----------------------------------------------

    ! ����ɶ���X��Z����ƽ���������һ������ŵӦ��      
    savename='ReyStr'//Cnum//'.dat'
    open(44,file=savename,form="formatted")
	write(44,*) 'Title = "Comput." '
    write(44,'(A)',advance='no') "variables=y<sup>+</sup>,<u'<sup>+</sup>u'<sup>+</sup>>, &
	    <v'<sup>+</sup>v'<sup>+</sup>>,<w'<sup>+</sup>w'<sup>+</sup>>,&
        <u'<sup>+</sup>v'<sup>+</sup>>,<u'<sup>+</sup>w'<sup>+</sup>>,<v'<sup>+</sup>w'<sup>+</sup>>"
	write(44,*) 'ZONE T="Comput." '
    !write(44,*) "zone i= ",nx, " j= ",ny
	    
    do j=2,ny-1
       
        write(44,"(7f16.8)") yplus(j), suua(j)/u_tau**2, svva(j)/u_tau**2,swwa(j)/u_tau**2, &
             suva(j)/u_tau**2, suwa(j)/u_tau**2, svwa(j)/u_tau**2
	   
    enddo
       
    close(44)
	    

 !   ! ���Z=0�������һ����������ŵ��Ӧ��
	!savename='ReyNorm2dXY'//Cnum//'.plt'
 !    open(46,file=savename,form="formatted")
 !   write(46,*) "variables=x,y,<ua'ua'>, <va'va'>, <wa'wa'>"
 !   write(46,*) "zone i= ",nx, " j= ",ny
	!    
 !   do j=1,ny
 !       do i=1,nx
 !           write(46,"(5f16.8)") xx(i),yy(j),uu2(i,j),vv2(i,j),ww2(i,j)
	!    
 !       enddo
 !   enddo
 !      
 !   close(46)
	    
	    
	    
	    
	    
	    
	    
	    
    end